<?php layout('app'); ?>

<?php section('title'); ?>
Reports
<?php endsection(); ?>

<?php section('content'); ?>
<div class="container mx-auto">
    <div class="row justify-content-center">
        <div class="">
            <div class="card">

                <div class="card-body">
                    <div class="card-title">
                        <div class="row align-items-center">
                            <div class="col text-left">
                                <h4>Reports</h4>
                            </div>
                            <div class="col">
                                <input type="text" id="searchInput" class="form-control" placeholder="Search items, who borrowed, status...">
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-success btn-sm" onclick="handleExportToExcel()">Export to Excel</button>
                            </div>
                        </div>
                    </div>
                    <table class="table table-sm text-sm text-capitalize">
                        <thead>
                            <tr>
                                <th scope="col" class="d-none">ID</th>
                                <th scope="col">Item</th>
                                <th scope="col">Category</th>
                                <th scope="col">Borrowed By</th>
                                <th scope="col">Borrowed Date</th>
                                <th scope="col">Returned Date</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody class="table-group-divider" id="reportTableBody">
                            <?php foreach ($borrowedItems as $bi): ?>
                                <tr>
                                    <td scope="row" class="d-none"><?php echo ($bi['id']); ?></td>
                                    <td><?php echo ($bi['item_name']); ?></td>
                                    <td><?php echo ($bi['category_name']); ?></td>
                                    <td><?php echo ($bi['user_name']); ?></td>
                                    <td><?php echo ($bi['borrowed_date']); ?></td>
                                    <td><?php echo ($bi['returned_date']); ?></td>
                                    <td><?php echo $bi['status']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endsection(); ?>

<?php section('scripts'); ?>
<script>
    document.getElementById('searchInput').addEventListener('input', function() {
        const searchValue = this.value.toLowerCase();
        const rows = document.querySelectorAll('#reportTableBody tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const match = Array.from(cells).some(cell => cell.textContent.toLowerCase().includes(searchValue));
            row.style.display = match ? '' : 'none';
        });
    });

    function handleDateChange() {
        const date = document.getElementById('reportDate').value;
        fetch(`/reports/filter-by-date?date=${date}`, {
            method: 'GET'
        }).then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('reportTableBody');
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td scope="row" class="d-none">${item.id}</td>
                    <td>${item.item_name}</td>
                    <td>${item.category_name}</td>
                    <td>${item.user_name}</td>
                    <td>${item.borrowed_date}</td>
                    <td>${item.returned_date}</td>
                    <td>${item.status}</td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => console.error('There was a problem with the fetch operation:', error));
    }

    function handleExportToExcel() {
        const date = document.getElementById('reportDate').value;
        fetch(`/reports/export-to-excel?date=${date}`, {
            method: 'GET'
        }).then(response => {
            if (response.ok) {
                return response.blob();
            }
            throw new Error('Network response was not ok.');
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'report.xlsx';
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
        })
        .catch(error => console.error('There was a problem with the fetch operation:', error));
    }
</script>
<?php endsection(); ?>