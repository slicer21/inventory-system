<?php layout('app'); ?>

<?php section('title'); ?>
    Users
<?php endsection(); ?>

<?php section('content'); ?>
<div class="container mt-5 mx-auto">
    <div class="row justify-content-center">
        <div class="">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">
                        <div class="row align-items-center">
                            <div class="col text-left">
                                <h4>Users</h4>
                            </div>
                            <div class="col-auto">
                                <a class="btn btn-primary btn-sm" href="users/create" >New</a>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col">
                            <input type="text" id="searchInput" class="form-control" placeholder="Search users...">
                        </div>
                    </div>
                    <table class="table table-sm text-capitalize" id="usersTable">
                        <thead>
                            <tr>
                                <th class="d-none">ID</th>
                                <th>Username</th>
                                <th>Name</th>
                                <th>Role</th>
                                <th>Qr Code</th>
                                <th>Default Password</th>
                                <th scope="col" width="10%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users['data'] as $user): ?>
                                <tr>
                                    <td class="d-none"><?php echo $user['id']; ?></td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['name']; ?></td>
                                    <td><?php echo $user['role']; ?></td>
                                    <td>
                                        <img src="<?php echo $user['qr_code']; ?>" alt="QR Code" style="width: 3rem;" />
                                    </td>
                                    <td><?php echo $user['default_password'];?></td>
                                    <td>
                                        <button type="button" class="btn btn-danger text-white btn-sm" onclick="generateQrCode(<?php echo $user['id']; ?>)">Generate QR</button>
                                        <button type="button" class="btn btn-success text-white btn-sm" onclick="passwordReset(<?php echo $user['id']; ?>)">Password Reset</button>
                                        <a type="button" href="users/<?php echo $user['id']; ?>/logs" class="btn btn-secondary text-white btn-sm mt-1">View Logs</a>  
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <!-- Pagination Links -->
                    <?php if ($users['total_pages'] > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <!-- Previous Page Link -->
                                <?php if ($users['previous_page_url']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo $users['previous_page_url']; ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">&laquo;</span>
                                    </li>
                                <?php endif; ?>

                                <!-- Page Numbers -->
                                <?php for ($page = 1; $page <= $users['total_pages']; $page++): ?>
                                    <li class="page-item <?php echo ($page == $users['current_page']) ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $page; ?>"><?php echo $page; ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Next Page Link -->
                                <?php if ($users['next_page_url']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo $users['next_page_url']; ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item disabled">
                                        <span class="page-link">&raquo;</span>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endsection(); ?>

<?php section('scripts'); ?>

<script>
    function generateQrCode(id) {
        fetch('/generate-qr-code/' + id, {
            method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.href = '/users';
            } else {
                alert(data.message);
            }
        })
        .catch(error => console.error('Error:', error));
    }

    function passwordReset(id) {
        fetch('/password-reset/' + id, {
            method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.message);
            } else {
                alert(data.message);
            }
        });
    }

    // Search functionality
    var searchInput = document.getElementById('searchInput');
    var table = document.getElementById('usersTable');
    var rows = table.getElementsByTagName('tr');

    searchInput.addEventListener('keyup', function () {
        var filter = searchInput.value.toLowerCase();
        for (var i = 1; i < rows.length; i++) {
            var cells = rows[i].getElementsByTagName('td');
            var match = false;
            for (var j = 0; j < cells.length; j++) {
                if (cells[j]) {
                    if (cells[j].innerText.toLowerCase().indexOf(filter) > -1) {
                        match = true;
                        break;
                    }
                }
            }
            if (match) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    });
</script>

<?php endsection(); ?>