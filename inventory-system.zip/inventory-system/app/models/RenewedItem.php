<?php

namespace app\Models;

use core\Model;

class RenewedItem extends Model
{
    protected $table = 'renewed_items';
}