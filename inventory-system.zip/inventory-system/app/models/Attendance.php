<?php

namespace app\Models;

use core\Model;

class Attendance extends Model
{
    protected $table = 'attendance';
}