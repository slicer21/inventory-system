<?php

namespace app\Models;

use core\Model;

class BorrowedItem extends Model
{
    protected $table = 'borrowed_items';
}