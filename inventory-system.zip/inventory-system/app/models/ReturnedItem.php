<?php

namespace app\Models;

use core\Model;

class ReturnedItem extends Model
{
    protected $table = 'returned_items';
}