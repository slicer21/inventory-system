<?php

return [
    'host' => 'localhost',
    'dbname' => 'inventory_system',
    'user' => 'root',
    'password' => '',
];
